# just-nodeJs-api-no-expressJs
This is a simple Rest API without the use of expressJs or any other framework

This Repo is a part a blog post,
here's a link to the blog http://bit.ly/39QcUKc

## Prerequisites
- Have nodeJs installed on your machine

## Running the code
- clone the project by running `git clone https://github.com/d-beloved/just-nodeJs-api-no-expressJs.git`
- run `npm install` on your terminal (not exactly neccesary as no package was used in this project)
- run `node server.js` the starting point of the app