module.exports = users = [
  {
    id: 1,
    name: 'Seyi',
    location: 'Buenos Aires'
  },

  {
    id: 2,
    name: 'David Khan',
    location: 'Argentina'
  },

  {
    id: 3,
    name: 'Isaac',
    location: 'Kwala lumpor'
  }
];
